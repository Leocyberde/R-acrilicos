import html2canvas from "html2canvas";
import jsPDF from "jspdf";

function waitForImages(element) {
  const imgs = Array.from(element.querySelectorAll("img"));
  if (imgs.length === 0) return Promise.resolve();
  return Promise.all(
    imgs.map(
      (img) =>
        new Promise((resolve) => {
          if (img.complete && img.naturalWidth > 0) {
            resolve();
          } else {
            img.onload = resolve;
            img.onerror = resolve;
          }
        })
    )
  );
}

export async function downloadPDF(elementId, filename) {
  const element = document.getElementById(elementId);
  if (!element) return;

  // Cria um container temporário visível para captura correta pelo html2canvas
  const container = document.createElement("div");
  container.style.cssText = "position:fixed;top:0;left:0;z-index:-9999;width:210mm;background:#fff;margin:0;padding:0;";
  const clone = element.cloneNode(true);
  clone.style.cssText = "margin:0;padding:0;line-height:normal;font-size:initial;";
  container.appendChild(clone);
  document.body.appendChild(container);

  // Aguarda todas as imagens carregarem
  await waitForImages(container);
  await new Promise((r) => setTimeout(r, 500));

  const canvas = await html2canvas(container, {
    scale: 2,
    useCORS: true,
    allowTaint: true,
    logging: false,
    backgroundColor: "#ffffff",
    windowWidth: container.scrollWidth,
    windowHeight: container.scrollHeight,
  });

  document.body.removeChild(container);

  const imgData = canvas.toDataURL("image/png");
  const pdf = new jsPDF({
    orientation: "portrait",
    unit: "mm",
    format: "a4",
  });

  const imgWidth = 210;
  const pageHeight = 297;
  const imgHeight = (canvas.height * imgWidth) / canvas.width;

  let remainingHeight = imgHeight;
  let yOffset = 0;

  pdf.addImage(imgData, "PNG", 0, yOffset, imgWidth, imgHeight);
  remainingHeight -= pageHeight;

  while (remainingHeight > 1) {
    yOffset -= pageHeight;
    pdf.addPage();
    pdf.addImage(imgData, "PNG", 0, yOffset, imgWidth, imgHeight);
    remainingHeight -= pageHeight;
  }

  pdf.save(filename);
}