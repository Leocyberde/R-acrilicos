import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Printer, Download } from "lucide-react";
import { toast } from "sonner";

export default function ExportTabs({ data, filename, columns, printTitle, printSubtitle, printExtra }) {
  const [exporting, setExporting] = useState(false);

  const handlePrint = () => {
    const { title, subtitle, tableHeaders, tableRows } = buildHtml();

    const html = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8"/>
        <title>${title}</title>
        <style>
          body { font-family: Arial, sans-serif; margin: 24px; color: #1e293b; }
          h1 { font-size: 20px; font-weight: bold; margin: 0 0 4px 0; }
          p { font-size: 13px; color: #64748b; margin: 0 0 20px 0; }
          table { width: 100%; border-collapse: collapse; }
          @media print { @page { margin: 15mm; } }
        </style>
      </head>
      <body>
        <h1>${title}</h1>
        <p>${subtitle}</p>
        ${printExtra || ""}
        <table>
          <thead><tr>${tableHeaders}</tr></thead>
          <tbody>${tableRows}</tbody>
        </table>
      </body>
      </html>
    `;

    const win = window.open("", "_blank");
    win.document.write(html);
    win.document.close();
    win.focus();
    setTimeout(() => { win.print(); win.close(); }, 500);
  };

  const buildHtml = () => {
    const title = printTitle || filename;
    const subtitle = printSubtitle || `${data.length} registros`;
    const tableHeaders = columns.map(col => `<th style="text-align:left;padding:6px 12px;font-size:11px;text-transform:uppercase;color:#64748b;border-bottom:2px solid #e2e8f0;">${col.label}</th>`).join("");
    const tableRows = data.map(item => {
      const cells = columns.map(col => {
        const value = item[col.key];
        const display = col.format ? col.format(value) : (value ?? "—");
        return `<td style="padding:8px 12px;font-size:13px;color:#1e293b;border-bottom:1px solid #f1f5f9;">${display}</td>`;
      }).join("");
      return `<tr>${cells}</tr>`;
    }).join("");
    return { title, subtitle, tableHeaders, tableRows };
  };

  const handlePDF = async () => {
    setExporting(true);
    try {
      const { jsPDF } = await import("jspdf");
      const html2canvas = (await import("html2canvas")).default;

      const { title, subtitle, tableHeaders, tableRows } = buildHtml();

      const container = document.createElement("div");
      container.style.cssText = "position:fixed;left:-9999px;top:0;width:794px;background:white;padding:32px;font-family:Arial,sans-serif;color:#1e293b;";
      container.innerHTML = `
        <h1 style="font-size:20px;font-weight:bold;margin:0 0 4px 0;">${title}</h1>
        <p style="font-size:13px;color:#64748b;margin:0 0 20px 0;">${subtitle}</p>
        ${printExtra || ""}
        <table style="width:100%;border-collapse:collapse;">
          <thead><tr>${tableHeaders}</tr></thead>
          <tbody>${tableRows}</tbody>
        </table>
      `;
      document.body.appendChild(container);

      const canvas = await html2canvas(container, { scale: 2, useCORS: true, backgroundColor: "#ffffff" });
      document.body.removeChild(container);

      const imgData = canvas.toDataURL("image/png");
      const pdf = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
      const pageW = pdf.internal.pageSize.getWidth();
      const pageH = pdf.internal.pageSize.getHeight();
      const imgW = pageW;
      const imgH = (canvas.height * imgW) / canvas.width;

      let y = 0;
      while (y < imgH) {
        if (y > 0) pdf.addPage();
        pdf.addImage(imgData, "PNG", 0, -y, imgW, imgH);
        y += pageH;
      }

      pdf.save(`${filename}.pdf`);
      toast.success("PDF gerado com sucesso");
    } catch (error) {
      console.error(error);
      toast.error("Erro ao gerar PDF");
    } finally {
      setExporting(false);
    }
  };

  const handleExcel = () => {
    setExporting(true);
    try {
      const csvData = data.map(item => {
        return columns.map(col => {
          const value = item[col.key];
          const displayValue = col.format ? col.format(value) : value;
          return `"${displayValue}"`;
        }).join(",");
      });

      const header = columns.map(col => `"${col.label}"`).join(",");
      const csvContent = [header, ...csvData].join("\n");
      
      const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
      const link = document.createElement("a");
      const url = URL.createObjectURL(blob);
      link.setAttribute("href", url);
      link.setAttribute("download", `${filename}.csv`);
      link.style.visibility = "hidden";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      toast.success("Arquivo exportado com sucesso");
    } catch (error) {
      console.error(error);
      toast.error("Erro ao exportar");
    } finally {
      setExporting(false);
    }
  };

  return (
    <div className="flex gap-2">
      <Button
        size="sm"
        variant="outline"
        onClick={handlePrint}
        disabled={exporting}
        className="text-xs"
      >
        <Printer className="h-3.5 w-3.5 mr-1.5" />
        Imprimir
      </Button>
      <Button
        size="sm"
        variant="outline"
        onClick={handlePDF}
        disabled={exporting}
        className="text-xs"
      >
        <Download className="h-3.5 w-3.5 mr-1.5" />
        PDF
      </Button>
      <Button
        size="sm"
        variant="outline"
        onClick={handleExcel}
        disabled={exporting}
        className="text-xs"
      >
        <Download className="h-3.5 w-3.5 mr-1.5" />
        Excel
      </Button>
    </div>
  );
}