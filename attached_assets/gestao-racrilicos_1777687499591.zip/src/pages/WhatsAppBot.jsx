import { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { MessageCircle, ExternalLink, RefreshCw, Send, Bot, User, CheckCircle } from "lucide-react";
import { Input } from "@/components/ui/input";

const AGENT_NAME = "atendimento_whatsapp";

export default function WhatsAppBot() {
  const [conversation, setConversation] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const [whatsappUrl, setWhatsappUrl] = useState(null);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    initConversation();
    loadWhatsAppUrl();
  }, []);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const loadWhatsAppUrl = () => {
    const url = base44.agents.getWhatsAppConnectURL(AGENT_NAME);
    setWhatsappUrl(url);
  };

  const initConversation = async () => {
    const conv = await base44.agents.createConversation({
      agent_name: AGENT_NAME,
      metadata: { name: "Teste de Atendimento" },
    });
    setConversation(conv);
    setMessages(conv.messages || []);

    base44.agents.subscribeToConversation(conv.id, (data) => {
      setMessages(data.messages || []);
    });
  };

  const sendMessage = async () => {
    if (!input.trim() || !conversation || sending) return;
    const text = input.trim();
    setInput("");
    setSending(true);
    await base44.agents.addMessage(conversation, { role: "user", content: text });
    setSending(false);
  };

  const handleKeyDown = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Bot de Atendimento WhatsApp</h1>
        <p className="text-slate-500 mt-1">Configure e teste seu assistente virtual de atendimento ao cliente</p>
      </div>

      {/* WhatsApp Connect Card */}
      <div className="bg-gradient-to-br from-green-50 to-emerald-50 border border-green-200 rounded-xl p-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="h-14 w-14 rounded-2xl bg-green-500 flex items-center justify-center shadow-lg">
              <MessageCircle className="h-7 w-7 text-white" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900">Conectar ao WhatsApp</h2>
              <p className="text-sm text-slate-600 mt-0.5">Clique no botão para vincular seu número de WhatsApp ao bot de atendimento</p>
              <div className="flex items-center gap-1.5 mt-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                <span className="text-xs text-green-700 font-medium">Bot pronto para uso</span>
              </div>
            </div>
          </div>
          <div className="flex gap-3">
            <Button
              onClick={() => window.open(whatsappUrl, "_blank")}
              className="bg-green-600 hover:bg-green-700 text-white gap-2"
              disabled={!whatsappUrl}
            >
              <MessageCircle className="h-4 w-4" />
              Conectar WhatsApp
              <ExternalLink className="h-3.5 w-3.5" />
            </Button>
          </div>
        </div>
      </div>

      {/* Info Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {[
          { icon: "📋", title: "Consulta Orçamentos", desc: "O bot informa o status dos orçamentos pelo nome do cliente" },
          { icon: "🔧", title: "Consulta O.S.", desc: "Clientes podem verificar o status das ordens de serviço" },
          { icon: "📝", title: "Solicita Orçamentos", desc: "Aceita novas solicitações de orçamento pelo WhatsApp" },
        ].map((item, i) => (
          <div key={i} className="bg-white rounded-xl border border-slate-200 p-4">
            <div className="text-2xl mb-2">{item.icon}</div>
            <h3 className="font-semibold text-slate-900 text-sm">{item.title}</h3>
            <p className="text-xs text-slate-500 mt-1">{item.desc}</p>
          </div>
        ))}
      </div>

      {/* Test Chat */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        <div className="flex items-center gap-3 px-5 py-4 border-b border-slate-100 bg-slate-50">
          <div className="h-8 w-8 rounded-full bg-indigo-100 flex items-center justify-center">
            <Bot className="h-4 w-4 text-indigo-600" />
          </div>
          <div>
            <p className="font-semibold text-slate-900 text-sm">Testar Bot</p>
            <p className="text-xs text-slate-500">Simule uma conversa como se fosse um cliente no WhatsApp</p>
          </div>
          <Button variant="ghost" size="icon" className="ml-auto h-8 w-8" onClick={initConversation} title="Nova conversa">
            <RefreshCw className="h-3.5 w-3.5 text-slate-400" />
          </Button>
        </div>

        <div className="h-96 overflow-y-auto p-4 space-y-3 bg-slate-50">
          {messages.filter(m => m.role !== "system").map((msg, i) => (
            <div key={i} className={`flex gap-2 ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
              {msg.role !== "user" && (
                <div className="h-7 w-7 rounded-full bg-indigo-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <Bot className="h-3.5 w-3.5 text-indigo-600" />
                </div>
              )}
              <div className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed ${
                msg.role === "user"
                  ? "bg-green-500 text-white rounded-br-sm"
                  : "bg-white text-slate-800 border border-slate-200 rounded-bl-sm"
              }`}>
                {msg.content}
              </div>
              {msg.role === "user" && (
                <div className="h-7 w-7 rounded-full bg-slate-200 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <User className="h-3.5 w-3.5 text-slate-600" />
                </div>
              )}
            </div>
          ))}
          {sending && (
            <div className="flex gap-2 justify-start">
              <div className="h-7 w-7 rounded-full bg-indigo-100 flex items-center justify-center flex-shrink-0">
                <Bot className="h-3.5 w-3.5 text-indigo-600" />
              </div>
              <div className="bg-white border border-slate-200 rounded-2xl rounded-bl-sm px-4 py-3">
                <div className="flex gap-1">
                  <span className="h-2 w-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
                  <span className="h-2 w-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                  <span className="h-2 w-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        <div className="p-4 border-t border-slate-100 flex gap-2">
          <Input
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Digite uma mensagem como se fosse um cliente..."
            disabled={sending || !conversation}
          />
          <Button onClick={sendMessage} disabled={sending || !input.trim() || !conversation} className="bg-green-600 hover:bg-green-700">
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}