import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Printer, Trash2, Edit, Download } from "lucide-react";
import { usePrint } from "@/hooks/usePrint";
import BudgetForm from "@/components/BudgetForm";
import ReceiptPrintLayoutMultiPage from "@/components/ReceiptPrintLayoutMultiPage";
import { downloadPDF } from "@/components/DownloadPDF";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export default function ReceiptDetail() {
  const { printElement } = usePrint();
  const [receipt, setReceipt] = useState(null);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);

  const navigate = useNavigate();
  const params = new URLSearchParams(window.location.search);
  const id = params.get("id");

  useEffect(() => {
    async function load() {
      const data = await base44.entities.Receipt.list();
      const found = data.find(r => r.id === id);
      setReceipt(found);
      setLoading(false);
    }
    load();
  }, [id]);

  const handleDelete = async () => {
    await base44.entities.Receipt.delete(id);
    navigate(createPageUrl("Receipts"));
  };

  const handleUpdate = async (data) => {
    setSaving(true);
    await base44.entities.Receipt.update(id, {
      client_name: data.client_name,
      client_phone: data.client_phone,
      client_email: data.client_email,
      client_address: data.client_address,
      job: data.job,
      producer: data.producer,
      description: data.description,
      items: data.items,
      subtotal: data.subtotal,
      discount: data.discount,
      total_amount: data.total,
      total_label: data.total_label,
      apply_margin: data.apply_margin,
      margin_percentage: data.margin_percentage,
      total_with_margin: data.total_with_margin,
      total_with_margin_label: data.total_with_margin_label,
      notes: data.notes,
    });
    const updated = await base44.entities.Receipt.list();
    setReceipt(updated.find(r => r.id === id));
    setSaving(false);
    setEditing(false);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="h-8 w-8 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!receipt) {
    return (
      <div className="text-center py-16">
        <p className="text-slate-500">Recibo não encontrado</p>
        <Button className="mt-4" onClick={() => navigate(createPageUrl("Receipts"))}>Voltar</Button>
      </div>
    );
  }

  if (editing) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => setEditing(false)}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Editar Recibo</h1>
            <p className="text-slate-500 mt-0.5">#{receipt.id?.slice(-6)}</p>
          </div>
        </div>
        <div className="bg-white rounded-xl border border-slate-200 p-6">
          <BudgetForm
            initialData={{
              client_name: receipt.client_name,
              client_phone: receipt.client_phone,
              client_email: receipt.client_email,
              client_address: receipt.client_address,
              job: receipt.job,
              producer: receipt.producer,
              description: receipt.description,
              items: receipt.items || [],
              notes: receipt.notes,
              status: "aprovado",
            }}
            onSubmit={handleUpdate}
            onCancel={() => setEditing(false)}
            loading={saving}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="no-print flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => navigate(createPageUrl("Receipts"))}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Recibo #{receipt.id?.slice(-6)}</h1>
            <p className="text-slate-500 mt-0.5">{receipt.client_name}</p>
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" size="sm" onClick={() => printElement('receipt-content')}>
            <Printer className="h-3.5 w-3.5 mr-1.5" /> Imprimir
          </Button>
          <Button variant="outline" size="sm" onClick={() => setEditing(true)}>
            <Edit className="h-3.5 w-3.5 mr-1.5" /> Editar
          </Button>
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="outline" size="sm" className="text-red-500 hover:text-red-600">
                <Trash2 className="h-3.5 w-3.5 mr-1.5" /> Excluir
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Excluir recibo?</AlertDialogTitle>
                <AlertDialogDescription>Esta ação não pode ser desfeita.</AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancelar</AlertDialogCancel>
                <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">Excluir</AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </div>

      {/* Visualização na tela */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 sm:p-8 space-y-6">
        {/* Dados do cliente */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pb-6 border-b border-slate-100">
          <div>
            <p className="text-xs text-slate-400 uppercase tracking-wider font-medium">Cliente</p>
            <p className="text-base font-semibold text-slate-900 mt-1">{receipt.client_name}</p>
          </div>
          {receipt.client_phone && (
            <div>
              <p className="text-xs text-slate-400 uppercase tracking-wider font-medium">Telefone</p>
              <p className="text-sm text-slate-700 mt-1">{receipt.client_phone}</p>
            </div>
          )}
          {receipt.client_email && (
            <div>
              <p className="text-xs text-slate-400 uppercase tracking-wider font-medium">Email</p>
              <p className="text-sm text-slate-700 mt-1">{receipt.client_email}</p>
            </div>
          )}
          {receipt.client_address && (
            <div>
              <p className="text-xs text-slate-400 uppercase tracking-wider font-medium">Endereço</p>
              <p className="text-sm text-slate-700 mt-1">{receipt.client_address}</p>
            </div>
          )}
          {receipt.job && (
            <div>
              <p className="text-xs text-slate-400 uppercase tracking-wider font-medium">Job</p>
              <p className="text-sm text-slate-700 mt-1">{receipt.job}</p>
            </div>
          )}
          {receipt.producer && (
            <div>
              <p className="text-xs text-slate-400 uppercase tracking-wider font-medium">Produtor</p>
              <p className="text-sm text-slate-700 mt-1">{receipt.producer}</p>
            </div>
          )}
          {receipt.emission_date && (
            <div>
              <p className="text-xs text-slate-400 uppercase tracking-wider font-medium">Data de Emissão</p>
              <p className="text-sm text-slate-700 mt-1">{new Date(receipt.emission_date).toLocaleDateString("pt-BR")}</p>
            </div>
          )}
          {receipt.due_date && (
            <div>
              <p className="text-xs text-slate-400 uppercase tracking-wider font-medium">Vencimento</p>
              <p className="text-sm text-slate-700 mt-1">{new Date(receipt.due_date).toLocaleDateString("pt-BR")}</p>
            </div>
          )}
          {receipt.payment_method && (
            <div>
              <p className="text-xs text-slate-400 uppercase tracking-wider font-medium">Forma de Pagamento</p>
              <p className="text-sm text-slate-700 mt-1 capitalize">{receipt.payment_method.replace("_", " ")}</p>
            </div>
          )}
        </div>

        {/* Descrição */}
        {receipt.description && (
          <div className="pb-6 border-b border-slate-100">
            <p className="text-xs text-slate-400 uppercase tracking-wider font-medium mb-1">Descrição</p>
            <p className="text-sm text-slate-700">{receipt.description}</p>
          </div>
        )}

        {/* Itens */}
        {receipt.items?.length > 0 && (
          <div className="pb-6 border-b border-slate-100">
            <p className="text-xs text-slate-400 uppercase tracking-wider font-medium mb-3">Itens</p>
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-200">
                  <th className="text-left text-xs font-semibold text-slate-500 uppercase py-2 pr-4">#</th>
                  <th className="text-left text-xs font-semibold text-slate-500 uppercase py-2 pr-4">Item</th>
                  <th className="text-center text-xs font-semibold text-slate-500 uppercase py-2 pr-4">Qtd</th>
                  <th className="text-right text-xs font-semibold text-slate-500 uppercase py-2 pr-4">V. Unit.</th>
                  <th className="text-right text-xs font-semibold text-slate-500 uppercase py-2">Subtotal</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {receipt.items.map((item, i) => (
                  <tr key={i}>
                    <td className="py-2.5 pr-4 text-sm text-slate-400">{i + 1}</td>
                    <td className="py-2.5 pr-4 text-sm text-slate-800">{item.name}</td>
                    <td className="py-2.5 pr-4 text-sm text-slate-600 text-center">{item.quantity}</td>
                    <td className="py-2.5 pr-4 text-sm text-slate-600 text-right">
                      {item.unit_price != null ? `R$ ${Number(item.unit_price).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}` : "-"}
                    </td>
                    <td className="py-2.5 text-sm text-slate-700 font-medium text-right">
                      {item.unit_price != null ? `R$ ${(Number(item.quantity || 0) * Number(item.unit_price)).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}` : "-"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Totais */}
        <div className="flex flex-col items-end gap-2 pb-6 border-b border-slate-100">
          {receipt.subtotal != null && (
            <div className="flex gap-8 text-sm">
              <span className="text-slate-500">Subtotal</span>
              <span className="font-medium text-slate-800 w-32 text-right">R$ {Number(receipt.subtotal).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</span>
            </div>
          )}
          {receipt.discount > 0 && (
            <div className="flex gap-8 text-sm">
              <span className="text-slate-500">Desconto ({receipt.discount}%)</span>
              <span className="font-medium text-red-600 w-32 text-right">- R$ {(Number(receipt.subtotal) * Number(receipt.discount) / 100).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</span>
            </div>
          )}
          {receipt.total_amount != null && (
            <div className="flex gap-8 text-sm">
              <span className="text-slate-500 font-semibold">{receipt.total_label || "Total sem Nota"}</span>
              <span className="font-bold text-slate-900 w-32 text-right">R$ {Number(receipt.total_amount).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</span>
            </div>
          )}
          {receipt.apply_margin && receipt.total_with_margin != null && (
            <div className="flex gap-8 text-sm">
              <span className="text-slate-500 font-semibold">{receipt.total_with_margin_label || "Total com Nota"} ({receipt.margin_percentage}%)</span>
              <span className="font-bold text-indigo-700 w-32 text-right">R$ {Number(receipt.total_with_margin).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</span>
            </div>
          )}
        </div>

        {/* Parcelas */}
        {receipt.installments?.length > 0 && (
          <div className="pb-6 border-b border-slate-100">
            <p className="text-xs text-slate-400 uppercase tracking-wider font-medium mb-3">Parcelas</p>
            <div className="space-y-2">
              {receipt.installments.map((inst, i) => (
                <div key={i} className="flex items-center justify-between text-sm py-1.5 border-b border-slate-50">
                  <span className="text-slate-500">Parcela {inst.number}</span>
                  <span className="text-slate-500">{inst.due_date ? new Date(inst.due_date).toLocaleDateString("pt-BR") : "-"}</span>
                  <span className={`font-medium ${inst.status === "pago" ? "text-emerald-600" : inst.status === "vencido" ? "text-red-600" : "text-slate-800"}`}>
                    R$ {Number(inst.amount).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                  </span>
                  <span className={`text-xs px-2 py-0.5 rounded-full ${inst.status === "pago" ? "bg-emerald-100 text-emerald-700" : inst.status === "vencido" ? "bg-red-100 text-red-700" : "bg-amber-100 text-amber-700"}`}>
                    {inst.status}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Observações */}
        {receipt.notes && (
          <div>
            <p className="text-xs text-slate-400 uppercase tracking-wider font-medium mb-1">Observações</p>
            <p className="text-sm text-slate-600">{receipt.notes}</p>
          </div>
        )}
      </div>

      {/* Layout de impressão/PDF - oculto na tela */}
      <div style={{ position: "fixed", left: "-9999px", top: 0, opacity: 0, pointerEvents: "none" }}>
        <div id="receipt-content" style={{ lineHeight: "normal", fontSize: "initial", margin: 0, padding: 0 }}>
          <ReceiptPrintLayoutMultiPage receipt={receipt} />
        </div>
      </div>
    </div>
  );
}